
// The Server
1. Start glassfish
2. In the admin panel -> Deploy an application
3. Choose file -> testmaven\target\testmaven-1.0-SNAPSHOT.jar
4. Set the Application Name to "Testserver"
5. Deploy

// The Client
1. Open "Testclient" project in NetBeans
2. Run Main.java
